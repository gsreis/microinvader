package com.ibm.space.space;

import java.io.StringReader;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/")
public class Space {
	
	// this will be moved to a registry pattern
	public static String[] urls = { "http://" + System.getProperty("enemy", "127.0.0.1:9083") + "/enemy-1.0/", 
            						"http://" + System.getProperty("player" , "127.0.0.1:9084") + "/player-1.0/",
            						"http://" + System.getProperty("bomb" , "127.0.0.1:9081") + "/bomb-1.0/", 
            						"http://" + System.getProperty("collision" , "127.0.0.1:9082") + "/collision-1.0/"};

    @GET
	@Path("/position")
    @Produces("application/json")
	public Response  position() throws Exception {
    	JsonArrayBuilder allelements = Json.createArrayBuilder();
    	for (int i = 0; i < urls.length; i++) {
			String json = callRest(urls[i] + "position");
			JsonArray array = Json.createReader(new StringReader(json)).readArray();
			for (int j = 0; j < array.size(); j++) {
				System.out.println(array.get(j));
				allelements.add(array.get(j));
			}
		}
    	return Response.status(200).entity(allelements.build()).build();
    }
    
    @GET
	@Path("/run")
    public void run() throws Exception {
    	for (int i = 0; i < urls.length; i++)
        	callRest(urls[i] + "run");
    }

	@GET
	@Path("/destroy/{id}")
	public void create(@PathParam("id") int id) throws Exception {
    	for (int i = 0; i < urls.length; i++)
        	callRest(urls[i] + "destroy/" + id);
	}

    @GET
	@Path("/move/{key}")
	public void move(@PathParam("key") String key) throws Exception {	
    	for (int i = 0; i < urls.length; i++)
        	callRest(urls[i] + "move/" + key);   	
    }
    
    @GET
	@Path("/create/{x}/{y}/{fromPlayer}")
	public void create(@PathParam("x") String x, @PathParam("y") String y, @PathParam("fromPlayer") String up) throws Exception {
    	for (int j = 0; j < urls.length; j++) {
			if (urls[j].indexOf("bomb") != -1)
				callRest(urls[j] + "create/" + x + "/" + y + "/" + up);
		}
    	
    }
    
    
    @GET
	@Path("/isFinished")
    @Produces("application/json")
	public Response isFinished() throws Exception {	
    	boolean finished = false;
    	for (int i = 0; i < urls.length; i++) {
        	String json = callRest(urls[i] + "isFinished"); 
        	JsonObject jobj = Json.createReader(new StringReader(json)).readObject();
        	if (jobj != null && jobj.getBoolean("finished"))
        		finished = true;
    	}
    	return Response.status(200).entity(Json.createObjectBuilder().add("finished", finished).build()).build();
    }   
    
	private String  callRest(String urlin) {
		try {
		  Client client = ClientBuilder.newClient();
		  return client.target(urlin).request(MediaType.APPLICATION_JSON).get(String.class);
		}catch(Exception e) { }
		return "[]";
	}
    
}

