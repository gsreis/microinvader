#!/bin/bash

cd bomb
mvn install liberty:run-server &
echo "bomb creation started"
cd ..
cd collision
mvn install liberty:run-server &
echo "collision creation started"
cd ..
cd enemy
mvn install liberty:run-server &
echo "enemy creation started"
cd ..
cd player
mvn install liberty:run-server &
echo "player creation started"
cd ..
cd space
mvn install liberty:run-server &
echo "space creation started"
cd ..



